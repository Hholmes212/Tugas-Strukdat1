﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

string firstFriend = "Maria";
string secondFriend = "Sage";
Console.WriteLine ($"My friends are {firstFriend} and {secondFriend}");
