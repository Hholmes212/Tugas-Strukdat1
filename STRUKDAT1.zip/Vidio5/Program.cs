﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

string firstFriend = "          Maria       ";
firstFriend = firstFriend.Trim();



string secondFriend = "         Scott        ";
Console.WriteLine ($"My friends are {firstFriend} and {secondFriend.Trim()}");
